/* ============================================================
 * Computes C = A * B
 * A : M x K  (row-major)
 * B : K x N  (row-major)
 * C : M x N  (row-major)
 * ============================================================ */

#include <riscv_vector.h>

void matmul(float *A, float *B, float *C, int M, int K, int N) {
    int x = 0;
    
    for (; x <= M - 8; x += 8) {
        size_t vl;
        for (int y = 0; y < N; y += vl) {
            vl = __riscv_vsetvl_e32m2(N - y);

            vfloat32m2_t vc0 = __riscv_vfmv_v_f_f32m2(0.0f, vl);
            vfloat32m2_t vc1 = __riscv_vfmv_v_f_f32m2(0.0f, vl);
            vfloat32m2_t vc2 = __riscv_vfmv_v_f_f32m2(0.0f, vl);
            vfloat32m2_t vc3 = __riscv_vfmv_v_f_f32m2(0.0f, vl);
            vfloat32m2_t vc4 = __riscv_vfmv_v_f_f32m2(0.0f, vl);
            vfloat32m2_t vc5 = __riscv_vfmv_v_f_f32m2(0.0f, vl);
            vfloat32m2_t vc6 = __riscv_vfmv_v_f_f32m2(0.0f, vl);
            vfloat32m2_t vc7 = __riscv_vfmv_v_f_f32m2(0.0f, vl);

            for (int z = 0; z < K; z++) {
                float a0 = A[(x + 0) * K + z];
                float a1 = A[(x + 1) * K + z];
                float a2 = A[(x + 2) * K + z];
                float a3 = A[(x + 3) * K + z];
                float a4 = A[(x + 4) * K + z];
                float a5 = A[(x + 5) * K + z];
                float a6 = A[(x + 6) * K + z];
                float a7 = A[(x + 7) * K + z];

                vfloat32m2_t vb = __riscv_vle32_v_f32m2(&B[z * N + y], vl);

                vc0 = __riscv_vfmacc_vf_f32m2(vc0, a0, vb, vl);
                vc1 = __riscv_vfmacc_vf_f32m2(vc1, a1, vb, vl);
                vc2 = __riscv_vfmacc_vf_f32m2(vc2, a2, vb, vl);
                vc3 = __riscv_vfmacc_vf_f32m2(vc3, a3, vb, vl);
                vc4 = __riscv_vfmacc_vf_f32m2(vc4, a4, vb, vl);
                vc5 = __riscv_vfmacc_vf_f32m2(vc5, a5, vb, vl);
                vc6 = __riscv_vfmacc_vf_f32m2(vc6, a6, vb, vl);
                vc7 = __riscv_vfmacc_vf_f32m2(vc7, a7, vb, vl);
            }

            // 寫回memory
            __riscv_vse32_v_f32m2(&C[(x + 0) * N + y], vc0, vl);
            __riscv_vse32_v_f32m2(&C[(x + 1) * N + y], vc1, vl);
            __riscv_vse32_v_f32m2(&C[(x + 2) * N + y], vc2, vl);
            __riscv_vse32_v_f32m2(&C[(x + 3) * N + y], vc3, vl);
            __riscv_vse32_v_f32m2(&C[(x + 4) * N + y], vc4, vl);
            __riscv_vse32_v_f32m2(&C[(x + 5) * N + y], vc5, vl);
            __riscv_vse32_v_f32m2(&C[(x + 6) * N + y], vc6, vl);
            __riscv_vse32_v_f32m2(&C[(x + 7) * N + y], vc7, vl);
        }
    }

    for (; x <= M - 4; x += 4) {
        size_t vl;
        for (int y = 0; y < N; y += vl) {
            vl = __riscv_vsetvl_e32m4(N - y);
            vfloat32m4_t vc0 = __riscv_vfmv_v_f_f32m4(0.0f, vl);
            vfloat32m4_t vc1 = __riscv_vfmv_v_f_f32m4(0.0f, vl);
            vfloat32m4_t vc2 = __riscv_vfmv_v_f_f32m4(0.0f, vl);
            vfloat32m4_t vc3 = __riscv_vfmv_v_f_f32m4(0.0f, vl);
            for (int z = 0; z < K; z++) {
                vfloat32m4_t vb = __riscv_vle32_v_f32m4(&B[z * N + y], vl);
                vc0 = __riscv_vfmacc_vf_f32m4(vc0, A[(x + 0) * K + z], vb, vl);
                vc1 = __riscv_vfmacc_vf_f32m4(vc1, A[(x + 1) * K + z], vb, vl);
                vc2 = __riscv_vfmacc_vf_f32m4(vc2, A[(x + 2) * K + z], vb, vl);
                vc3 = __riscv_vfmacc_vf_f32m4(vc3, A[(x + 3) * K + z], vb, vl);
            }
            __riscv_vse32_v_f32m4(&C[(x + 0) * N + y], vc0, vl);
            __riscv_vse32_v_f32m4(&C[(x + 1) * N + y], vc1, vl);
            __riscv_vse32_v_f32m4(&C[(x + 2) * N + y], vc2, vl);
            __riscv_vse32_v_f32m4(&C[(x + 3) * N + y], vc3, vl);
        }
    }

    for (; x < M; x++) {
        size_t vl;
        for (int y = 0; y < N; y += vl) {
            vl = __riscv_vsetvl_e32m8(N - y);
            vfloat32m8_t vc = __riscv_vfmv_v_f_f32m8(0.0f, vl);
            for (int z = 0; z < K; z++) {
                vfloat32m8_t vb = __riscv_vle32_v_f32m8(&B[z * N + y], vl);
                vc = __riscv_vfmacc_vf_f32m8(vc, A[x * K + z], vb, vl);
            }
            __riscv_vse32_v_f32m8(&C[x * N + y], vc, vl);
        }
    }
}