if (N == 32) {
    // 32x32
    for (i = 0; i < N; i += 8) {
        for (j = 0; j < N; j += 8) {
            for (k = i; k < i + 4; ++k) {
                t0 = A[k][j]; t1 = A[k][j+1]; t2 = A[k][j+2]; t3 = A[k][j+3];
                t4 = A[k][j+4]; t5 = A[k][j+5]; t6 = A[k][j+6]; t7 = A[k][j+7];
                B[j][k] = t0; B[j+1][k] = t1; B[j+2][k] = t2; B[j+3][k] = t3;
                B[j][k+4] = t4; B[j+1][k+4] = t5; B[j+2][k+4] = t6; B[j+3][k+4] = t7;
            }
            for (k = j; k < j + 4; ++k) {
                t0 = B[k][i+4]; t1 = B[k][i+5]; t2 = B[k][i+6]; t3 = B[k][i+7];
                t4 = A[i+4][k]; t5 = A[i+5][k]; t6 = A[i+6][k]; t7 = A[i+7][k];
                B[k][i+4] = t4; B[k][i+5] = t5; B[k][i+6] = t6; B[k][i+7] = t7;
                B[k+4][i] = t0; B[k+4][i+1] = t1; B[k+4][i+2] = t2; B[k+4][i+3] = t3;
            }
            for (k = i + 4; k < i + 8; ++k) {
                t4 = A[k][j+4]; t5 = A[k][j+5]; t6 = A[k][j+6]; t7 = A[k][j+7];
                B[j+4][k] = t4; B[j+5][k] = t5; B[j+6][k] = t6; B[j+7][k] = t7;
            }
        }
    }
}
else if (N == 64) {
    for (i = 0; i < N; i += 8) {
        for (j = 0; j < N; j += 8) {
            if (i == j) {
                // diagonal
                for (k = i; k < i + 8; k += 4) {
                    for (l = j; l < j + 8; l += 4) {
                        t0 = A[k][l];   t1 = A[k][l+1];   t2 = A[k][l+2];   t3 = A[k][l+3];
                        t4 = A[k+1][l]; t5 = A[k+1][l+1]; t6 = A[k+1][l+2]; t7 = A[k+1][l+3];
                        B[l][k] = t0;   B[l+1][k] = t1;   B[l+2][k] = t2;   B[l+3][k] = t3;
                        B[l][k+1] = t4; B[l+1][k+1] = t5; B[l+2][k+1] = t6; B[l+3][k+1] = t7;

                        t0 = A[k+2][l]; t1 = A[k+2][l+1]; t2 = A[k+2][l+2]; t3 = A[k+2][l+3];
                        t4 = A[k+3][l]; t5 = A[k+3][l+1]; t6 = A[k+3][l+2]; t7 = A[k+3][l+3];
                        B[l][k+2] = t0; B[l+1][k+2] = t1; B[l+2][k+2] = t2; B[l+3][k+2] = t3;
                        B[l][k+3] = t4; B[l+1][k+3] = t5; B[l+2][k+3] = t6; B[l+3][k+3] = t7;
                    }
                }
            }
            else {
                // non-diagonal
                for (k = i; k < i + 4; ++k) {
                    t0 = A[k][j]; t1 = A[k][j+1]; t2 = A[k][j+2]; t3 = A[k][j+3];
                    t4 = A[k][j+4]; t5 = A[k][j+5]; t6 = A[k][j+6]; t7 = A[k][j+7];
                    B[j][k] = t0; B[j+1][k] = t1; B[j+2][k] = t2; B[j+3][k] = t3;
                    B[j][k+4] = t4; B[j+1][k+4] = t5; B[j+2][k+4] = t6; B[j+3][k+4] = t7;
                }
                
                for (k = 0; k < 4; ++k) {
                    t0 = B[j+k][i+4]; t1 = B[j+k][i+5]; t2 = B[j+k][i+6]; t3 = B[j+k][i+7];
                    t4 = A[i+4][j+k]; t5 = A[i+5][j+k]; t6 = A[i+6][j+k]; t7 = A[i+7][j+k];
                    
                    B[j+k][i+4] = t4; B[j+k][i+5] = t5; B[j+k][i+6] = t6; B[j+k][i+7] = t7;
                    B[j+k+4][i] = t0; B[j+k+4][i+1] = t1; B[j+k+4][i+2] = t2; B[j+k+4][i+3] = t3;
                    
                    t0 = A[i+4][j+k+4]; t1 = A[i+5][j+k+4]; t2 = A[i+6][j+k+4]; t3 = A[i+7][j+k+4];
                    B[j+k+4][i+4] = t0; B[j+k+4][i+5] = t1; B[j+k+4][i+6] = t2; B[j+k+4][i+7] = t3;
                }
            }
        }
    }
}